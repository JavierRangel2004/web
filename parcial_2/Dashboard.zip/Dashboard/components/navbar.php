<nav class = "navbar fixed-top navbar-expand-lg bg-dark">
    <div class="container-fluid">   
            <a class="navbar-brand ms-lg-2 py-2 px-3 rounded bg-white "height="50"href="#">Talent UP</a>
            
    </div>
</nav>
<script rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css"></script>
