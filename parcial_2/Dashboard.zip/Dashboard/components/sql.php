<?php

$servername = "localhost";
$username = "pantera";
$password = "cualquiera";
$dbname = "panteras2";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

?>